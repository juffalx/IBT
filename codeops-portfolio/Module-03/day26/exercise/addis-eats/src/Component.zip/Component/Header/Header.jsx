import './Header.css'


function Header(){
    return(
        <div>
            <h1 className='heading-title'>Header For Practice</h1>
        </div>
    )
}
export default Header;