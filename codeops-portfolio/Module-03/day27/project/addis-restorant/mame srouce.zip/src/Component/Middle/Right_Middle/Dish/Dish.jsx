import Card from "./Card"

function Dish({name, price, category, spicy}) {
  return (
    <Card>
        <h3>{name}</h3>
        <p>{price}</p>
        {Boolean(spicy) && <p>Spicy </p>}
        <button>Add</button>
    </Card>
  )
}

export default Dish