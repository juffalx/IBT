import './Header.css'

import React from 'react'

function Header() {
  return (
    <div>
        <div className='logo'>
            <h3>Habesha Eater</h3>
        </div>

    </div>
  )
}

export default Header