
function Button({name}) {
  return (
    
        <button onClick={() => value = {name}}>{name}</button>
    
  )
}

export default Button