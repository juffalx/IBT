import React from 'react'

function Footer() {
  return (
    <div className='footer'>
        <p>&copy 2026 footer</p>
    </div>
  )
}

export default Footer